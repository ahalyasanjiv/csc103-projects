#!/bin/bash

./check > output
